// Auto generated BSF Invoker source code

// Add proper package name
// e.g. package com.motivian.bpm.pqh_conf_interest.util.bsf;

import net.velti.workflow.ProcessData;
import net.velti.workflow.sql2java.core.Activity;
import net.velti.workflow.sql2java.core.ActivityInstance;

public class PQH_CONF_INTEREST_v1 {
    protected ProcessData pd;
    protected Activity activity;
    protected ActivityInstance activityInstance;
    protected long pid;

    public PQH_CONF_INTEREST_v1(ProcessData pd, Activity activity, ActivityInstance activityInstance, long pid)
    {
        this.pd = pd;
        this.activity = activity;
        this.activityInstance = activityInstance;
        this.pid = pid;
    }

    public void START_J() throws Exception {
        System.out.println("START JOIN of Process Instance "+pid+" invoked");
    }

    public void START_S() throws Exception {
        System.out.println("START SPLIT of Process Instance "+pid+" invoked");
    }

    public void ACTIVITY_1_J() throws Exception {
        System.out.println("ACTIVITY_1 JOIN of Process Instance "+pid+" invoked");
    }

    public void ACTIVITY_1_S() throws Exception {
        System.out.println("ACTIVITY_1 SPLIT of Process Instance "+pid+" invoked");
    }

    public void ACTIVITY_2_J() throws Exception {
        System.out.println("ACTIVITY_2 JOIN of Process Instance "+pid+" invoked");
    }

    public void ACTIVITY_2_S() throws Exception {
        System.out.println("ACTIVITY_2 SPLIT of Process Instance "+pid+" invoked");
    }

    public void END_J() throws Exception {
        System.out.println("END JOIN of Process Instance "+pid+" invoked");
    }

    public void END_S() throws Exception {
        System.out.println("END SPLIT of Process Instance "+pid+" invoked");
    }

}

