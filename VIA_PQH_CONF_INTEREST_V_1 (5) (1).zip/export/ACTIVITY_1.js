<script>
// On page javascript

function x(){ x=1; }
</script>
