// Implementation of JOIN (before) script

