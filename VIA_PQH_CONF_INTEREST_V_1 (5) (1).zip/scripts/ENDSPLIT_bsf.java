// Implementation of SPLIT (after) script

